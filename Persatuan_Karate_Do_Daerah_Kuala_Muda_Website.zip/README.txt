PERSATUAN KARATE DO DAERAH KUALA MUDA — WEBSITE

1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox or Safari.
3. Keep the assets folder beside index.html so the two uploaded photos load correctly.
4. The WhatsApp button opens a chat with 018-947 5156.

To publish it online, upload index.html and the assets folder to any static website host.
